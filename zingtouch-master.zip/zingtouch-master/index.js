require('./dist/zingtouch.min.js');
module.exports = ZingTouch;
